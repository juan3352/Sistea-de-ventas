package sisventaesq;

import Vista.Login;


public class SisventaESQ {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Login lg = new Login();
        lg.setVisible(true);
    }

}
