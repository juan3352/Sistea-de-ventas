
import os
import numpy as np
from tkinter import messagebox



print('inicia')
dataPath = 'C:/Users/juanc/Documents/NetBeansProjects/sisventaESQ/src/BioEmpleados'#Cambia a la ruta donde hayas almacenado Data
peopleList = os.listdir(dataPath)
print (dataPath)
print('Lista de personas: ', peopleList)
labels = []
facesData = []
for nameDir in peopleList:
    personPath = dataPath + '/' + nameDir
    print(nameDir)
    print('Leyendo las im�genes')
    for fileName in os.listdir(personPath):
        print('Rostros: ', nameDir + '/' + fileName)
        labels.append(label)
        facesData.append(cv2.imread(personPath+'/'+fileName,0))
        #image = cv2.imread(personPath+'/'+fileName,0)
        #cv2.imshow('image',image)
        #cv2.waitKey(10)
    label = label + 1


#### Entrenando ####
print("Entrenando...")
face.train(facesData, np.array())
print('...Entrenamiento finalizado')

#### guardando el archivo de entrenamiento ####
face_recognizer.write('modeloLBPHFace.xml')


messagebox.showinfo(message="Entrenamiento Finalizado", title="Entrenador")


