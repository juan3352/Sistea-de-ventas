import cv2
import os
import imutils



###dialogo input
from tkinter import simpledialog

ROOT = tk.Tk()

ROOT.withdraw()
# the input dialog
USER_INP = simpledialog.askstring(title="Introducir nombre de nuevo empleado",
                                  prompt="Nombre o Id del nuevo empleado :")

# check it out
print("Hello", USER_INP)
###



nombre = USER_INP
print(nombre)
personName = nombre

dataPath = 'C:/Users/juanc/Documents/NetBeansProjects/sisventaESQ/src/BioEmpleados'#Cambia a la ruta donde hayas almacenado Data
personPath = dataPath + '/' + personName
cap = cv2.VideoCapture(0,cv2.CAP_DSHOW)
#cap = cv2.VideoCapture('Video.mp4')
faceClassif = cv2.CascadeClasifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
count = 0
while True:
    
    ret, frame = cap.read()
    if ret == False: break
    frame =  imutils.resize(frame, width=640)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = faceClassif.detectMultiScale(gray,1.3,5)
    for (x,y,w,h) in faces:
        cv2.rectangle(frame, (x,y),(x+w,y+h),(0,255,0),2)        
        rostro = cv2.resize(rostro,(150,150),interpolation=cv2.INTER_CUBIC)
        cv2.imwrite(personPath + '/rostro_{}.jpg'.format(count),rostro)
        count = count + 1
    cv2.imshow('frame',frame)
    if k == 27 or count >= 300:
        break
cap.release()
cv2.destroyAllWindows()